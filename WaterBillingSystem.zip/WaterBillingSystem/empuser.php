<center><h1>Add User</h1>
<form method="post" action="empadd.php">
<table width="200" border="1">
<tr>
    <td>id:</td>
    <td><input type="text" name="id" /></td>
  </tr>
<tr>
    <td>First Name:</td>
    <td><input type="text" name="fname" /></td>
  </tr>
  <tr>
    <td>Last Name:</td>
    <td><input type="text" name="lname" /></td>
  </tr>
  <tr>
    <td>Address:</td>
    <td><input type="text" name="address" /></td>
  </tr>
  <tr>
    <td>Contact:</td>
    <td><input type="text" name="contact" /></td>
  </tr>
  <tr>
    <td>Username:</td>
    <td><input type="text" name="username" /></td>
  </tr>
  <tr>
    <td>Password:</td>
    <td><input type="text" name="password" /></td>
  </tr>
  
    <td><input type="submit" name="ok" value="Add"/></td>
    <td>&nbsp;</td>
  </tr>
</table>

</form>




</center>